Module 3 code examples - Coming soon
